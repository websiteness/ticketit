<?php

return [

'data' => '
	<b>:name</b> a créé un nouveau ticket concernant <b>:subject</b><br>
	Il est actuellement :status dans la catégorie :category, et il vous a été assigné.<br>
',

];

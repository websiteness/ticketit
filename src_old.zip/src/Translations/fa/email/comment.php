<?php

return [

'data' => '
	<b>:name</b> به تیکت: <b>:subject</b> پاسخ داده است<br>
	<b>دسته تیکت:</b> :category - <b>وضعیت:</b> :status<br>
	<br>
	<div><b>:comment</b></div><br>
',

];

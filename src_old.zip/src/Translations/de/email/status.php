<?php

return [

'data' => '<b>:name</b> hat den Status für ":subject" von :old_status auf :new_status gesetzt<br>',

];

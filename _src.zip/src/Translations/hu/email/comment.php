<?php

return [

'data' => '
	<b>:name</b> hozzászólt a következő kérelemhez: :subject<br>
	<b>Kategória:</b> :category - <b>Státusz:</b> :status<br>
	<br>
	<div>:comment</div><br>
',

];

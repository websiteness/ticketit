<?php

return [

'data' => '
	<b>:name</b> új kérelmet hozott létre <b>:subject</b> tárggyal<br>
	:status státusszal :category kategóriában, és ez önhöz lett rendelve.<br>
',

];

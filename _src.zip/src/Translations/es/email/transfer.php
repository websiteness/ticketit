<?php

return [

'data' => '<b>:name</b> transfirió el tiquete "<b>:subject</b>" de :agent en :old_category a usted en :new_category<br>',

];

<?php

return [
    'data' => '<b>:name</b> alterado o status de ":subject" para :old_status para :new_status<br>',
];

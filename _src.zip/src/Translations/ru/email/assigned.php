<?php

return [

'data' => '
	<b>:name</b> добавил тикет <b>:subject</b><br>
	со статусом :status в категории :category, который был назначен вам.<br>
',

];

<?php

return [

'data' => '
	<b>:name</b> оставил комментарий к тикету: <b>:subject</b><br>
	<b>Категория:</b> :category - <b>статус:</b> :status<br>
	<br>
	<div><b>:comment</b></div><br>
',

];

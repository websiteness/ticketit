<?php

return [

    'data' => '<b>:name</b> перенес тикет "<b>:subject</b>" с агента :agent категории :old_category вам в категорию :new_category<br>',

];

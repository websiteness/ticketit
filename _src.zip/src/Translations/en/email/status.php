<?php

return [

'data' => '
	User <b>:name</b>
	Ticket#: <b>:id</b> 
	Title: <b>:subject</b>
	From <b>:old_status</b> to <b>:new_status</b><br>',

];

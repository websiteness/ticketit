<?php

return [

'data' => '<b>:name</b> has transferred the ticket "<b>#:id :subject</b>" from :agent in :old_category to you in :new_category<br>',

];

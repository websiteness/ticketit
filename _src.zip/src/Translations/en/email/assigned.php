<?php

return [

'data' => '
	Ticket#: <b>:id</b><br>
	Title: <b>:subject</b><br>
	User: <b>:name</b><br>
	Status: <b>:status</b><br>
	Category: <b>:category</b><br>
	Sub Category: <b>:sub_category</b><br>
	<br>
	<div style="text-align : left;">:content</div>
',

];
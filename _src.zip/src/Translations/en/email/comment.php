<?php

return [

'data' => '
	<div style="text-align:left; color:#187272">
		Hello :name, <br>
		<br>
		Lead Generated support has replied to the ticket you created. <br>

		Ticket <b>#:id </b><br>
		Title: <b>:subject</b><br>
		Ticket Status: <b> :status</b><br>
		<br>
		Reply from Lead Generated Support:<br> 
		<div>:comment</div><br>
		<br>
		Lead Generated Support <br>
		support@leadgenerated.com<br>
	</div>
',

];

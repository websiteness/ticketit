<?php

return [

'data' => '<b>:name</b> ha trasferito il ticket di assistenza  "<b>:subject</b>" da :agent in :old_category a te in :new_category<br>',

];

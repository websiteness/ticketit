<?php

return [

    'assigned'    => 'Ticket Assegnati',
    'comment'     => 'Nuovo Commento',
    'status'      => 'Stato Cambiato',
    'transfer'    => 'Ticket Trasferito',
    'view-ticket' => 'Clicca qui per vedere il tuo ticket.',

];

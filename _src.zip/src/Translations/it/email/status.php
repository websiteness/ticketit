<?php

return [

'data' => '<b>:name</b> ha cambiato lo stato di  ":subject" da :old_status a :new_status<br>',

];

<?php

return [

'data' => '
	<b>:name</b> a ajouté un commentaire à propos du ticket : <b>:subject</b><br>
	<b>Categorie:</b> :category - <b>statut:</b> :status<br>
	<br>
	<div><b>:comment</b></div><br>
',

];

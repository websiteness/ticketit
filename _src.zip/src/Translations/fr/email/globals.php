<?php

return [

    'assigned'    => 'Ticket pris en charge',
    'comment'     => 'Nouveau Commentaire',
    'status'      => 'Modification du Statut',
    'transfer'    => 'Ticket Transféré',
    'view-ticket' => 'Cliquez ici pour suivre votre ticket.',

];

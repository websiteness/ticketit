<?php

return [

    'data' => '
	<b>:name</b> علق على التذكرة: <b>:subject</b><br>
	<b>تصنيف التذكرة:</b> :category - <b>الحالة:</b> :status<br>
	<br>
	<div><b>:comment</b></div><br>
',

];

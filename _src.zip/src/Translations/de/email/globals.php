<?php

return [

    'assigned'    => 'Ticket zugewiesen',
    'comment'     => 'Neuer Kommentar',
    'status'      => 'Status aktualisiert',
    'transfer'    => 'Ticket verschoben',
    'view-ticket' => 'Hier klicken um das Ticket anzuzeigen.',

];

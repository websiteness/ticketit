<?php

return [

'data' => '<b>:name</b> hat das Ticket "<b>:subject</b>" von :agent in :old_category zu Dir in :new_category verschoben<br>',

];

<div class="card-footer">
    <div class="text-center">{!! $records->render("pagination::bootstrap-4") !!}</div>
</div>

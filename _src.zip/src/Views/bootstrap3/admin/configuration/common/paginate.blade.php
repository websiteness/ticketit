<div class="panel-footer">
      <div class="text-center">{!! $records->render() !!}</div>
    </div>

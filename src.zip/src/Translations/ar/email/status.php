<?php

return [

    'data' => '<b>:name</b> قام بتغيير حالة التذكرة ":subject" من :old_status إلى :new_status<br>',

];

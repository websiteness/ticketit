<?php

return [

    'assigned'    => 'تعيين تذكرة',
    'comment'     => 'تعليق جديد',
    'status'      => 'الحالة تغيرت',
    'transfer'    => 'تذكرة منقولة',
    'view-ticket' => 'اضغط هنا لعرض التذكرة.',

];

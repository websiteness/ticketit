<?php

return [

'data' => '<b>:name</b> a transféré le ticket "<b>:subject</b>" de :agent dans la catégorie :old_category vers vous dans la catégorie :new_category<br>',

];

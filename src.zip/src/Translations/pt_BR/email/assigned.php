<?php

return [

    'data' => '
        <b>:name</b> Criado Novo Chamado <b>:subject</b><br>
        :status na :category, foi atribuido a você.<br>
    ',
];

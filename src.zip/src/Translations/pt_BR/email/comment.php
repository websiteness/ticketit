<?php

return [
    'data' => '
        <b>:name</b> comentou sobre o chamado: <b>:subject</b><br>
        <b>Categoria do chamado:</b> :category - <b>Status:</b> :status<br>
    <br>
        <div><b>:comment</b></div><br>
    ',
];

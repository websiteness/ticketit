<?php

namespace Kordy\Ticketit\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Kordy\Ticketit\Models\Category;
use Kordy\Ticketit\Models\Agent;

use Kordy\Ticketit\Services\CategoriesService;

class CategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $categories = \Cache::remember('ticketit::categories', 60, function () {
            return Category::all();
        });

        return view('ticketit::admin.category.index', compact('categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        $categories = Category::all()->pluck( 'name', 'id'); 
        return view('ticketit::admin.category.create', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name'      => 'required',
            'color'     => 'required',
            'parent'    => 'required'
        ]);

        $category = new Category();
        $category->create(['name' => $request->name, 'color' => $request->color, 'parent' => $request->parent]);

        Session::flash('status', trans('ticketit::lang.category-name-has-been-created', ['name' => $request->name]));

        \Cache::forget('ticketit::categories');

        return redirect()->action('\Kordy\Ticketit\Controllers\CategoriesController@index');
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        return 'All category related agents here';
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $category = Category::findOrFail($id);
        $categories = Category::all()->pluck( 'name', 'id'); 
        return view('ticketit::admin.category.edit', compact('category', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param int     $id
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'name'      => 'required',
            'color'     => 'required',
        ]);

        $category = Category::findOrFail($id);
        $category->update(['name' => $request->name, 'color' => $request->color, 'parent' => $request->parent]);

        Session::flash('status', trans('ticketit::lang.category-name-has-been-modified', ['name' => $request->name]));

        \Cache::forget('ticketit::categories');

        return redirect()->action('\Kordy\Ticketit\Controllers\CategoriesController@index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $category = Category::findOrFail($id);
        $name = $category->name;
        $category->delete();

        Session::flash('status', trans('ticketit::lang.category-name-has-been-deleted', ['name' => $name]));

        \Cache::forget('ticketit::categories');

        return redirect()->action('\Kordy\Ticketit\Controllers\CategoriesController@index');
    }

    public function viewCategoryOwners(CategoriesService $category_service)
    {
        $agents = Agent::agents()->get();
        $categories = $category_service->getAllCategories();

        return view('ticketit::admin.category.owners', compact('agents', 'categories'));
    }

    public function storeCategoryOwners(Request $request, CategoriesService $category_service)
    {
        $category_service->setCategoryOwners($request->owners);

        return redirect()->back();
    }

    public function getZones($id, CategoriesService $category_service)
    {
       $category = $category_service->getZones($id);
       return response($category, 200);
    }


}
